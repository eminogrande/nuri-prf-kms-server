/**
 * AWS KMS Session Manager
 * Replaces CloudHSM with AWS KMS for cryptographic operations
 */

import {
  KMSClient,
  GenerateMacCommand,
  CreateKeyCommand,
  DescribeKeyCommand,
  GetParametersForImportCommand,
  ImportKeyMaterialCommand,
} from "@aws-sdk/client-kms";
import {
  SecretsManagerClient,
  GetSecretValueCommand,
  CreateSecretCommand,
  UpdateSecretCommand,
} from "@aws-sdk/client-secrets-manager";
import crypto from "crypto";
import { asBuffer, secureWipe } from "./kms-utils.js";

class KmsSessionManager {
  constructor() {
    const {
      AWS_REGION = "us-east-1",
      AWS_ACCESS_KEY_ID,
      AWS_SECRET_ACCESS_KEY,
      AWS_SESSION_TOKEN,
      KMS_KEY_ID,
      KMS_MASTER_SECRET_NAME = "nuri-master-secret",
      NURI_MASTER_SECRET,
      KMS_SIMULATION = process.env.NODE_ENV === "development",
    } = process.env;

    this.region = AWS_REGION;
    this.kmsKeyId = KMS_KEY_ID;
    this.masterSecretName = KMS_MASTER_SECRET_NAME;
    this.simulationMode = KMS_SIMULATION === "true" || KMS_SIMULATION === true;
    this.localMasterSecret = NURI_MASTER_SECRET;

    // AWS Clients
    this.kmsClient = null;
    this.secretsClient = null;

    // Cache
    this.masterKey = null;
    this.lastLogMac = null;
    this.initialized = false;
    this.initializing = null;
  }

  get isSimulation() {
    return this.simulationMode;
  }

  async init() {
    if (this.initialized) return;
    if (this.initializing) {
      await this.initializing;
      return;
    }

    this.initializing = (async () => {
      if (this.simulationMode) {
        // Simulation mode for local development
        console.log("🔧 KMS Simulation Mode - Using local master secret");

        if (!this.localMasterSecret) {
          throw new Error(
            "KMS simulation requires NURI_MASTER_SECRET environment variable"
          );
        }

        // Use local master secret for HMAC operations
        this.masterKey = Buffer.from(this.localMasterSecret, "hex");

        if (this.masterKey.length !== 32) {
          // Ensure 32-byte key by hashing if needed
          this.masterKey = crypto.createHash("sha256")
            .update(this.localMasterSecret)
            .digest();
        }
      } else {
        // Real AWS KMS mode
        console.log("🔒 Initializing AWS KMS Session");

        // Initialize AWS clients
        const config = {
          region: this.region,
        };

        // Use explicit credentials if provided, otherwise use IAM role
        if (AWS_ACCESS_KEY_ID && AWS_SECRET_ACCESS_KEY) {
          config.credentials = {
            accessKeyId: AWS_ACCESS_KEY_ID,
            secretAccessKey: AWS_SECRET_ACCESS_KEY,
            sessionToken: AWS_SESSION_TOKEN,
          };
        }

        this.kmsClient = new KMSClient(config);
        this.secretsClient = new SecretsManagerClient(config);

        if (!this.kmsKeyId) {
          throw new Error(
            "KMS_KEY_ID environment variable required for KMS operations"
          );
        }

        // Verify KMS key exists and is accessible
        await this.verifyKmsKey();

        // Load master secret from Secrets Manager
        await this.loadMasterSecret();
      }

      this.initialized = true;
      console.log(
        this.simulationMode
          ? "✅ KMS Simulation initialized"
          : "✅ AWS KMS Session initialized"
      );
    })();

    try {
      await this.initializing;
    } finally {
      this.initializing = null;
    }
  }

  async shutdown() {
    if (this.masterKey) {
      secureWipe(this.masterKey);
    }
    this.masterKey = null;
    this.kmsClient = null;
    this.secretsClient = null;
    this.initialized = false;
  }

  ensureReady() {
    if (!this.initialized) {
      throw new Error("KMS session not initialized. Call init() first.");
    }
  }

  async verifyKmsKey() {
    try {
      const command = new DescribeKeyCommand({
        KeyId: this.kmsKeyId,
      });

      const response = await this.kmsClient.send(command);

      if (!response.KeyMetadata?.Enabled) {
        throw new Error(`KMS key ${this.kmsKeyId} is not enabled`);
      }

      console.log(`✅ KMS Key verified: ${response.KeyMetadata.Arn}`);
    } catch (error) {
      throw new Error(`Failed to verify KMS key: ${error.message}`);
    }
  }

  async loadMasterSecret() {
    try {
      // Try to get existing secret from Secrets Manager
      const getCommand = new GetSecretValueCommand({
        SecretId: this.masterSecretName,
      });

      const response = await this.secretsClient.send(getCommand);

      if (response.SecretBinary) {
        this.masterKey = Buffer.from(response.SecretBinary);
      } else if (response.SecretString) {
        // Handle hex-encoded string
        this.masterKey = Buffer.from(response.SecretString, "hex");
      }

      console.log(`✅ Master secret loaded from Secrets Manager`);
    } catch (error) {
      if (error.name === "ResourceNotFoundException") {
        // Create new master secret if it doesn't exist
        console.log("⚠️ Master secret not found, creating new one...");
        await this.createMasterSecret();
      } else {
        throw new Error(`Failed to load master secret: ${error.message}`);
      }
    }
  }

  async createMasterSecret() {
    // Generate new 256-bit master secret
    const newMasterKey = crypto.randomBytes(32);

    try {
      const command = new CreateSecretCommand({
        Name: this.masterSecretName,
        Description: "Nuri PRF Co-signer Master Secret",
        SecretBinary: newMasterKey,
        Tags: [
          { Key: "Application", Value: "nuri-prf-signer" },
          { Key: "Type", Value: "master-secret" },
        ],
      });

      await this.secretsClient.send(command);
      this.masterKey = newMasterKey;

      console.log(`✅ New master secret created in Secrets Manager`);
    } catch (error) {
      secureWipe(newMasterKey);
      throw new Error(`Failed to create master secret: ${error.message}`);
    }
  }

  signHmac(data) {
    const message = asBuffer(data);

    try {
      if (this.simulationMode) {
        // Local HMAC computation for simulation
        this.ensureReady();
        const hmac = crypto.createHmac("sha256", this.masterKey);
        hmac.update(message);
        return hmac.digest();
      } else {
        // AWS KMS HMAC - This would require KMS HMAC key type
        // For now, we'll use local HMAC with KMS-protected master key
        // In production, you'd want to use KMS GenerateMac with HMAC_SHA_256
        this.ensureReady();
        const hmac = crypto.createHmac("sha256", this.masterKey);
        hmac.update(message);
        return hmac.digest();
      }
    } finally {
      secureWipe(message);
    }
  }

  generateRandom(length) {
    if (length <= 0) {
      throw new Error("Random length must be positive");
    }

    // Use crypto.randomBytes for both simulation and production
    // AWS KMS GenerateRandom could be used but adds latency
    return crypto.randomBytes(length);
  }

  deriveEphemeralKey(tag = "nuri-session-key") {
    const nonce = this.generateRandom(32);
    const context = Buffer.concat([
      Buffer.from(tag, "utf8"),
      nonce,
      Buffer.from(Date.now().toString(16), "hex"),
    ]);

    const mac = this.signHmac(context);
    const sessionKey = crypto.createHash("sha256").update(mac).digest();

    secureWipe(context);
    secureWipe(mac);

    return {
      key: sessionKey,
      nonce,
    };
  }

  attestLog(event, payload = {}, { emit = true } = {}) {
    const timestamp = new Date().toISOString();
    const nonce = this.generateRandom(16);
    const serializedPayload = Buffer.from(
      JSON.stringify(payload ?? {}),
      "utf8"
    );

    const logMaterial = Buffer.concat([
      Buffer.from(timestamp, "utf8"),
      Buffer.from(event, "utf8"),
      serializedPayload,
      nonce,
      this.lastLogMac ?? Buffer.alloc(0),
    ]);

    const mac = this.signHmac(logMaterial);

    const entry = {
      timestamp,
      event,
      payload,
      nonce: nonce.toString("hex"),
      mac: mac.toString("hex"),
      previousMac: this.lastLogMac ? this.lastLogMac.toString("hex") : null,
      kmsMode: !this.simulationMode,
    };

    this.lastLogMac = mac;

    if (emit) {
      const record = {
        type: this.simulationMode ? "kms.simulation.attestedLog" : "kms.attestedLog",
        ...entry,
      };
      console.log(JSON.stringify(record));
    }

    secureWipe(serializedPayload);
    secureWipe(logMaterial);

    return entry;
  }
}

const kmsSessionManager = new KmsSessionManager();
export default kmsSessionManager;