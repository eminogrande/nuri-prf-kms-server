#!/usr/bin/env node

import crypto from 'crypto';
import { secp256k1 } from '@noble/curves/secp256k1.js';

// Test PRF and wallet ID
const testPRF = Buffer.from('deadbeefcafebabedeadbeefcafebabe', 'hex');
const testWalletId = 'test-wallet-123';

// Original server's key derivation (server-prf-encrypted.js)
function deriveOriginalKey(prfBytes, walletId) {
  const seed = crypto.createHash('sha256')
    .update(prfBytes)
    .update(Buffer.from('nuri-cosigner', 'utf8'))
    .update(Buffer.from(walletId, 'utf8'))
    .digest();

  const privateKey = seed.slice(0, 32);
  const publicKey = secp256k1.getPublicKey(privateKey, true);

  return {
    seed: seed.toString('hex'),
    publicKey: publicKey.toString('hex')
  };
}

// Test both servers via HTTP
async function testServers() {
  console.log('\n🧪 Testing Key Derivation Compatibility\n');
  console.log('═══════════════════════════════════════\n');

  // Calculate expected key from original algorithm
  const expected = deriveOriginalKey(testPRF, testWalletId);
  console.log('📋 Test Parameters:');
  console.log(`   PRF: ${testPRF.toString('hex')}`);
  console.log(`   Wallet ID: ${testWalletId}`);
  console.log('\n✅ Expected (Original Algorithm):');
  console.log(`   Seed: ${expected.seed.slice(0, 32)}...`);
  console.log(`   Public Key: ${expected.publicKey.slice(0, 32)}...`);

  // Test KMS server on port 1337
  try {
    const response = await fetch(`http://localhost:1337/derive_key`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prf_bytes: testPRF.toString('base64'),
        wallet_id: testWalletId
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }

    const result = await response.json();
    console.log('\n🔐 KMS Server Response:');
    console.log(`   Public Key: ${result.public_key.slice(0, 32)}...`);
    console.log(`   X-Only: ${result.xonly_pubkey.slice(0, 32)}...`);

    // Convert base64 response to hex for comparison
    const kmsPublicKey = Buffer.from(result.public_key, 'base64').toString('hex');

    if (kmsPublicKey === expected.publicKey) {
      console.log('\n✅ SUCCESS: Keys match perfectly!');
      console.log('   The KMS server is 100% compatible with the original server.');
    } else {
      console.log('\n❌ FAILURE: Keys do not match!');
      console.log(`   Expected: ${expected.publicKey}`);
      console.log(`   Got:      ${kmsPublicKey}`);
    }

  } catch (error) {
    console.error('\n❌ Error testing KMS server:', error.message);
  }

  console.log('\n═══════════════════════════════════════\n');
}

// Run tests
testServers().catch(console.error);